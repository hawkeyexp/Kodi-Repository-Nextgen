#!/usr/bin/python
# -*- coding: utf-8 -*-

import time
import xbmc
import xbmcgui

if __name__ == '__main__':
    monitor = xbmc.Monitor()
    xbmc.log("service.skin.viewswitcher - Start service", level=xbmc.LOGNOTICE)
    while not monitor.abortRequested():
        # Sleep/wait for abort for 10 seconds
        if monitor.waitForAbort(0.5):
            # Abort was requested while waiting. We should exit
            break
        if not xbmc.getCondVisibility("Skin.HasSetting(SkinHelper.ForcedViews.Enabled)") == 1:
            current_content = xbmc.getInfoLabel("Container.Content")
            if current_content == "movies":
                if xbmc.getInfoLabel("Container.Content(sets)") ==1:
                    current_content = "setmovies"
            
            if current_content in "movies|setmovies|tvshows|seasons|episodes|albums|artists|musicvideos|pictures|videos|files":

                current_view_label = xbmc.getInfoLabel("Container.Viewmode").decode("utf-8")
                dest_view_id = xbmc.getInfoLabel("Skin.String(SkinHelper.ForcedViews.%s)" % current_content).decode("utf-8")
                dest_view_label = xbmc.getInfoLabel("Skin.String(SkinHelper.ForcedViews.%s.label)" % current_content).decode("utf-8")
        
                if dest_view_id != "":
                    if current_view_label != dest_view_label:
                        xbmc.executebuiltin("Container.SetViewMode(%s)" % dest_view_id)
                        xbmc.log("service.skin.viewswitcher - Cur label: " + current_view_label, level=xbmc.LOGNOTICE)
                        xbmc.log("service.skin.viewswitcher - Cur id: " + str(current_content), level=xbmc.LOGNOTICE)
                        xbmc.log("service.skin.viewswitcher - Switching to:", level=xbmc.LOGNOTICE)
                        xbmc.log("service.skin.viewswitcher - Dest label: " + str(dest_view_label), level=xbmc.LOGNOTICE)
                        xbmc.log("service.skin.viewswitcher - Dest id: " + str(dest_view_id), level=xbmc.LOGNOTICE)

LibreELEC Dev Updater
=========================

This [Kodi](http://kodi.tv) addon for [LibreELEC](http://www.libreelec.tv) enables downloading of various development build updates and releases directly from the GUI.

![LibreELEC Dev Updater](http://devupdater.leopold.me.uk/screenshots/builds.png)

import xbmcgui
import time
import os
import socket


xbmcgui.Dialog().notification('RadioFM-Update', 'Vorbereitung...', xbmcgui.NOTIFICATION_INFO, 5000)
os.system("sudo rm -r /tmp/plugin.program.radioFM/");
xbmcgui.Dialog().notification('RadioFM-Update', 'Download...', xbmcgui.NOTIFICATION_INFO, 50000)
os.system("git clone https://github.com/hawkeyexp/plugin.program.radioFM /tmp/plugin.program.radioFM -b nextgen");
xbmcgui.Dialog().notification('RadioFM-Update', 'Installiere Update', xbmcgui.NOTIFICATION_INFO, 10000)
os.system("sudo rm -r /tmp/plugin.program.radioFM/.git/");
os.system("sudo rm -r /home/pi/.kodi/addons/plugin.program.radioFM/");
os.system("sudo mkdir /home/pi/.kodi/addons/plugin.program.radioFM/");
os.system("sudo rsync -r /tmp/plugin.program.radioFM/ /home/pi/.kodi/addons/plugin.program.radioFM");
os.system("sudo rm -r /tmp/plugin.program.radioFM/");
xbmcgui.Dialog().notification('RadioFM-Update', 'Aktualisierung abgeschlossen', xbmcgui.NOTIFICATION_INFO, 5000)
#xbmc.executebuiltin('ReloadSkin()');








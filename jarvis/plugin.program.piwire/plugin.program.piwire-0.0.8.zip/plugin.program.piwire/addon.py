import sys
import xbmc
import xbmcgui
import xbmcaddon

# Get global paths
addon = xbmcaddon.Addon(id='plugin.program.piwire')
addonpath = addon.getAddonInfo('path').decode("utf-8")

def mapSensors(command):
    commandlist = addon.getSetting('sensorlist')
    command_list = commandlist.split(',')
    mapping = xbmcgui.Dialog().select('$ADDON[plugin.program.piwire 32055]',command_list)
    addon.setSetting('fieldmap' + str(command), command_list[mapping])
    quit()

count = len(sys.argv) - 1
if count == 1:
    given_arg = int(sys.argv[1])
    if given_arg > 0 and given_arg < 9:
	mapSensors(given_arg)
    quit()

#control
HOME_BUTTON  = 1201
BACK_BUTTON  = 1202
BUTTON_FOCUS = 1203
SETTINGS_BUTTON  = 1204
ACTION_BACK  = 92

def updateSettings():
    xbmcgui.Window(10000).setProperty('field1',addon.getSetting('field1'))
    xbmcgui.Window(10000).setProperty('field2',addon.getSetting('field2'))
    xbmcgui.Window(10000).setProperty('field3',addon.getSetting('field3'))
    xbmcgui.Window(10000).setProperty('field4',addon.getSetting('field4'))
    xbmcgui.Window(10000).setProperty('field5',addon.getSetting('field5'))
    xbmcgui.Window(10000).setProperty('field6',addon.getSetting('field6'))
    xbmcgui.Window(10000).setProperty('field7',addon.getSetting('field7'))
    xbmcgui.Window(10000).setProperty('field8',addon.getSetting('field8'))
    xbmcgui.Window(10000).setProperty('showfield1',addon.getSetting('showfield1'))
    xbmcgui.Window(10000).setProperty('showfield2',addon.getSetting('showfield2'))
    xbmcgui.Window(10000).setProperty('showfield3',addon.getSetting('showfield3'))
    xbmcgui.Window(10000).setProperty('showfield4',addon.getSetting('showfield4'))
    xbmcgui.Window(10000).setProperty('showfield5',addon.getSetting('showfield5'))
    xbmcgui.Window(10000).setProperty('showfield6',addon.getSetting('showfield6'))
    xbmcgui.Window(10000).setProperty('showfield7',addon.getSetting('showfield7'))
    xbmcgui.Window(10000).setProperty('showfield8',addon.getSetting('showfield8'))

def clearValues():
    xbmcgui.Window(10000).setProperty('Temp1','n/a')
    xbmcgui.Window(10000).setProperty('Temp2','n/a')
    xbmcgui.Window(10000).setProperty('Temp3','n/a')
    xbmcgui.Window(10000).setProperty('Temp4','n/a')
    xbmcgui.Window(10000).setProperty('Temp5','n/a')
    xbmcgui.Window(10000).setProperty('Temp6','n/a')
    xbmcgui.Window(10000).setProperty('Temp7','n/a')
    xbmcgui.Window(10000).setProperty('Temp8','n/a')
    xbmcgui.Window(10000).setProperty('Trend1','')
    xbmcgui.Window(10000).setProperty('Trend2','')
    xbmcgui.Window(10000).setProperty('Trend3','')
    xbmcgui.Window(10000).setProperty('Trend4','')
    xbmcgui.Window(10000).setProperty('Trend5','')
    xbmcgui.Window(10000).setProperty('Trend6','')
    xbmcgui.Window(10000).setProperty('Trend7','')
    xbmcgui.Window(10000).setProperty('Trend8','')
    xbmcgui.Window(10000).setProperty('Text1',addon.getSetting('Text1'))
    xbmcgui.Window(10000).setProperty('Text2',addon.getSetting('Text2'))
    xbmcgui.Window(10000).setProperty('Text3',addon.getSetting('Text3'))
    xbmcgui.Window(10000).setProperty('Text4',addon.getSetting('Text4'))
    xbmcgui.Window(10000).setProperty('Text5',addon.getSetting('Text5'))
    xbmcgui.Window(10000).setProperty('Text6',addon.getSetting('Text6'))
    xbmcgui.Window(10000).setProperty('Text7',addon.getSetting('Text7'))
    xbmcgui.Window(10000).setProperty('Text8',addon.getSetting('Text8'))

updateSettings()

class piwire(xbmcgui.WindowXMLDialog):

    def onInit(self):
        piwire.button_home=self.getControl(HOME_BUTTON)
        piwire.button_back=self.getControl(BACK_BUTTON)
        piwire.buttonfocus=self.getControl(BUTTON_FOCUS)
        piwire.button_settings=self.getControl(SETTINGS_BUTTON)

    def onAction(self, action):
        global windowopen
        
    def onClick(self, controlID):

        if controlID == HOME_BUTTON:
	    xbmcgui.Window(10000).setProperty('visible','0')
            self.close()

        if controlID == BACK_BUTTON:
	    xbmcgui.Window(10000).setProperty('visible','0')
            self.close()

        if controlID == SETTINGS_BUTTON:
	    self.setFocus(self.buttonfocus)
	    addon.openSettings()
	    updateSettings()
	    clearValues()
	    self.setFocus(self.buttonfocus)

    def onFocus(self, controlID):
        pass
    
    def onControl(self, controlID):
        pass

xbmcgui.Window(10000).setProperty('visible','1') 
onewiredialog = piwire("Custom_PiWire.xml", addonpath, 'default', '720')

onewiredialog.doModal()
del onewiredialog

import os

os.system("sudo /sbin/ifup wlan0");


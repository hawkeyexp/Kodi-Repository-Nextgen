import os

os.system("sudo /etc/init.d/networking restart");

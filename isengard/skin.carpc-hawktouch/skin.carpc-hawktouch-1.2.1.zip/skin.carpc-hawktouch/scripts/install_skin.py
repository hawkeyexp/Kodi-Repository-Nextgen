import xbmcgui
import time
import os
import socket


xbmcgui.Dialog().notification('Skin-Update', 'Vorbereitung...', xbmcgui.NOTIFICATION_INFO, 5000)
os.system("sudo rm -r /tmp/skin.carpc-hawktouch/");
xbmcgui.Dialog().notification('Skin-Update', 'Download...', xbmcgui.NOTIFICATION_INFO, 50000)
os.system("git clone https://github.com/hawkeyexp/skin.carpc-hawktouch /tmp/skin.carpc-hawktouch");
xbmcgui.Dialog().notification('Skin-Update', 'Installiere Update', xbmcgui.NOTIFICATION_INFO, 10000)
os.system("sudo rm -r /tmp/skin.carpc-hawktouch/.git/");
os.system("sudo rm -r /home/pi/.kodi/addons/skin.carpc-hawktouch/");
os.system("sudo mkdir /home/pi/.kodi/addons/skin.carpc-hawktouch/");
os.system("sudo rsync -r /tmp/skin.carpc-hawktouch/ /home/pi/.kodi/addons/skin.carpc-hawktouch");
os.system("sudo rm -r /tmp/skin.carpc-hawktouch/");
xbmcgui.Dialog().notification('Skin-Update', 'Aktualisierung abgeschlossen', xbmcgui.NOTIFICATION_INFO, 5000)
xbmc.executebuiltin('ReloadSkin()');








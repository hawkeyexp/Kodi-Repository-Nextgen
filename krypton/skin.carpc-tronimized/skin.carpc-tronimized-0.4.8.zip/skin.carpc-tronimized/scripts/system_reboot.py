import os
import xbmc
import xbmcgui

xbmcgui.Window(10000).setProperty('syseventreboot','true')
os.system("sleep 1 && sudo reboot &")


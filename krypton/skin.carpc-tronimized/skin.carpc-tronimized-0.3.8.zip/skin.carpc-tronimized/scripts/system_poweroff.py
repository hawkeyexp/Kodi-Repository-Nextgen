import os
import xbmc
import xbmcgui

xbmcgui.Window(10000).setProperty('syseventshutdown','true')
os.system("sudo poweroff &")

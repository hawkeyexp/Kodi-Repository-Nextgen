import os
import xbmc
import xbmcgui

xbmcgui.Window(10000).setProperty('syseventreboot','true')
os.system("sudo reboot &")


import os
import xbmc
import xbmcgui
import time

#xbmcgui.Window(10000).setProperty('syseventshutdown','true')
#time.sleep(1)
xbmc.executebuiltin('quit');
os.system("sudo poweroff &")

import os
import xbmc
import xbmcgui
import time

xbmcgui.Window(10000).setProperty('syseventreboot','true')
time.sleep(1)
xbmc.executebuiltin('Reboot');
os.system("sudo reboot &")


import os
import xbmc
import xbmcgui
import time

xbmcgui.Window(10000).setProperty('syseventshutdown','true')
time.sleep(1)
xbmc.executebuiltin('XBMC.Quit');
time.sleep(1)
os.system("sudo poweroff");



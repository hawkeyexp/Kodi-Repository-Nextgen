# plugin.program.gpiodiag

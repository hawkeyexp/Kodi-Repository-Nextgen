import xbmc
import xbmcgui
import xbmcaddon
import time

# Get global paths
addon = xbmcaddon.Addon(id='plugin.program.carpc-xtouch')
addonpath = addon.getAddonInfo('path').decode("utf-8")
updating = 0

#control
HOME_BUTTON  = 1201
BACK_BUTTON  = 1202
BUTTON_FOCUS = 1203
SETTINGS_BUTTON  = 1204
LOADDAY_BUTTON  = 1205
LOADNIGHT_BUTTON  = 1206
SAVEDAY_BUTTON  = 1207
SAVENIGHT_BUTTON  = 1208
ACTION_BACK  = 92


COMMANDLIST = ['UseCustomBackground','Use_Startup_Playlist','HideAppSwitcher','HideWeatherTitleWidget','EnableTitleImage',
	'EnableTitleText','Hide1024x600Fix','EnableBGPictures','BGPicturesAllowFocus','EnableBGColor','CustomMenuRadioIcon1',
	'CustomMenuMusicIcon1','CustomMenuAlbumsIcon1','CustomMenuArtistsIcon1','CustomMenuGenresIcon1','CustomMenuVideoIcon1',
	'CustomMenuNaviIcon1','CustomMenuFavouritesIcon1','CustomMenuProgramsIcon1','CustomMenuOBDIcon1','CustomMenuWeatherIcon1',
	'CustomMenu3GIcon1','CustomMenuSettingsIcon1','CustomMenuShutdownIcon1','CustomMenuShutDownNoDialogIcon1',
	'CustomMenuRadioIcon2','CustomMenuMusicIcon2','CustomMenuAlbumsIcon2','CustomMenuArtistsIcon2','CustomMenuGenresIcon2',
	'CustomMenuVideoIcon2','CustomMenuNaviIcon2','CustomMenuFavouritesIcon2','CustomMenuProgramsIcon2','CustomMenuOBDIcon2',
	'CustomMenuWeatherIcon2','CustomMenu3GIcon2','CustomMenuSettingsIcon2','CustomMenuShutdownIcon2',
	'CustomMenuShutDownNoDialogIcon2','CustomMenuIcon2','CustomMenuRadioIcon3','CustomMenuMusicIcon3','CustomMenuAlbumsIcon3',
	'CustomMenuArtistsIcon3','CustomMenuGenresIcon3','CustomMenuVideoIcon3','CustomMenuNaviIcon3','CustomMenuFavouritesIcon3',
	'CustomMenuProgramsIcon3','CustomMenuOBDIcon3','CustomMenuWeatherIcon3','CustomMenu3GIcon3','CustomMenuSettingsIcon3',
	'CustomMenuShutdownIcon3','CustomMenuShutDownNoDialogIcon3','CustomMenuIcon3','CustomMenuRadioIcon4','CustomMenuMusicIcon4',
	'CustomMenuAlbumsIcon4','CustomMenuArtistsIcon4','CustomMenuGenresIcon4','CustomMenuVideoIcon4','CustomMenuNaviIcon4',
	'CustomMenuFavouritesIcon4','CustomMenuProgramsIcon4','CustomMenuOBDIcon4','CustomMenuWeatherIcon4','CustomMenu3GIcon4',
	'CustomMenuSettingsIcon4','CustomMenuShutdownIcon4','CustomMenuShutDownNoDialogIcon4','CustomMenuIcon4','CustomMenuRadioIcon5',
	'CustomMenuMusicIcon5','CustomMenuAlbumsIcon5','CustomMenuArtistsIcon5','CustomMenuGenresIcon5','CustomMenuVideoIcon5',
	'CustomMenuNaviIcon5','CustomMenuFavouritesIcon5','CustomMenuProgramsIcon5','CustomMenuOBDIcon5','CustomMenuWeatherIcon5',
	'CustomMenu3GIcon5','CustomMenuSettingsIcon5','CustomMenuShutdownIcon5','CustomMenuShutDownNoDialogIcon5','CustomMenuIcon5',
	'CustomMenuRadioIcon6','CustomMenuMusicIcon6','CustomMenuAlbumsIcon6','CustomMenuArtistsIcon6','CustomMenuGenresIcon6',
	'CustomMenuVideoIcon6','CustomMenuNaviIcon6','CustomMenuFavouritesIcon6','CustomMenuProgramsIcon6','CustomMenuOBDIcon6',
	'CustomMenuWeatherIcon6','CustomMenu3GIcon6','CustomMenuSettingsIcon6','CustomMenuShutdownIcon6','CustomMenuShutDownNoDialogIcon6',
	'CustomMenuIcon6','UseCustomLogo','HideVisualisationHome','UseVisBg','UseVisBgCover','HideHomeButtonMusicPlayerTitle',
	'HideHomeButtonRadioStationName','HideRandomRepeat','EnableBottomBG','EnablePlayerButtonsBG','HideHomeButtonMusic',
	'HideHomeButtonMusicArtists','HideHomeButtonMusicAlbums','HideHomeButtonMusicGenre','HideHomeButtonVideo',
	'HideHomeButtonNavigation','HideHomeButtonRadio','HideHomeButtonShutdownDialog','HideHomeButtonFileManager',
	'HideHomeButtonConnect3g','HideHomeButtonOBD','HideHomeButtonWeather','HideHomeButtonFavourites','HideHomeButtonPrograms',
	'HideHomeButtonConnectWiFi','HideHomeButtonDayNight','SubmenuIconsSmall','SubmenuIconsMid','SubmenuIconsBig',
	'EnableSubmenuBG','Enable_Clock_Animation','Show_Clock_white','Enable_Clock_Second_Hand','HideHomeButtonTime',
	'HideSettingsManager2.2','DebugGrid','DebugInfo','ShowOutlines','EnableTempOutput','UseVisBgFull','MediaSubMenuVisible2',
	'CustomBackgroundPath','TempSensor','CustomColorNofocus','HomeScreenTitleImage','HomeScreenTitle','Home1BG','Home1BGFocus',
	'HBSolidColor','HBTransparency','CustomColorFocus','HBOutlineColor','CustomColorHomebuttons','HomeButton1Value','MagicButtonIcon1',
	'CustomRadioIcon1','CustomMusicIcon1','CustomAlbumsIcon1','CustomArtistsIcon1','CustomGenresIcon1','CustomVideoIcon1',
	'CustomNaviIcon1','CustomFavouritesIcon1','CustomProgramsIcon1','CustomOBDIcon1','CustomWeatherIcon1','Custom3GIcon1',
	'SettingsIcon2','CustomMenuShutdownIcon1','CustomMenuShutDownNoDialogIcon1','CustomHomeButtonLabel1','Home2BG','Home2BGFocus',
	'HomeButton2Value','MagicButtonIcon2','CustomRadioIcon2','CustomMusicIcon2','CustomAlbumsIcon2','CustomArtistsIcon2',
	'CustomGenresIcon2','CustomVideoIcon2','CustomNaviIcon2','CustomFavouritesIcon2','CustomProgramsIcon2','CustomOBDIcon2',
	'CustomWeatherIcon2','Custom3GIcon2','CustomMenuShutdownIcon2','CustomMenuShutDownNoDialogIcon2','CustomMenuButtonIcon2',
	'CustomHomeButtonLabel2','Home3BG','Home3BGFocus','HomeButton3Value','MagicButtonIcon3','CustomRadioIcon3','CustomMusicIcon3',
	'CustomAlbumsIcon3','CustomArtistsIcon3','CustomGenresIcon3','CustomVideoIcon3','CustomNaviIcon3','CustomFavouritesIcon3',
	'CustomProgramsIcon3','CustomOBDIcon3','CustomWeatherIcon3','Custom3GIcon3','CustomMenuShutdownIcon3',
	'CustomMenuShutDownNoDialogIcon3','CustomMenuButtonIcon3','CustomHomeButtonLabel3','Home4BG','Home4BGFocus',
	'HomeButton4Value','MagicButtonIcon4','CustomRadioIcon4','CustomMusicIcon4','CustomAlbumsIcon4','CustomArtistsIcon4',
	'CustomGenresIcon4','CustomVideoIcon4','CustomNaviIcon4','CustomFavouritesIcon4','CustomProgramsIcon4','CustomOBDIcon4',
	'CustomWeatherIcon4','Custom3GIcon4','CustomMenuShutdownIcon4','CustomMenuShutDownNoDialogIcon4','CustomMenuButtonIcon4',
	'CustomHomeButtonLabel4','Home5BG','Home5BGFocus','HomeButton5Value','MagicButtonIcon5','CustomRadioIcon5','CustomMusicIcon5',
	'CustomAlbumsIcon5','CustomArtistsIcon5','CustomGenresIcon5','CustomVideoIcon5','CustomNaviIcon5','CustomFavouritesIcon5',
	'CustomProgramsIcon5','CustomOBDIcon5','CustomWeatherIcon5','Custom3GIcon5','CustomMenuShutdownIcon5',
	'CustomMenuShutDownNoDialogIcon5','CustomMenuButtonIcon5','CustomHomeButtonLabel5','Home6BG','Home6BGFocus',
	'HomeButton6Value','MagicButtonIcon6','CustomRadioIcon6','CustomMusicIcon6','CustomAlbumsIcon6','CustomArtistsIcon6',
	'CustomGenresIcon6','CustomVideoIcon6','CustomNaviIcon6','CustomFavouritesIcon6','CustomProgramsIcon6','CustomOBDIcon6',
	'CustomWeatherIcon6','Custom3GIcon6','CustomMenuShutdownIcon6','CustomMenuShutDownNoDialogIcon6','CustomMenuButtonIcon6',
	'CustomHomeButtonLabel6','CustomLogoPath','CustomVisBgPath','BottomBGColor','BottomBGTransparency','PlayerButtonsBGColor',
	'PlayerButtonsBGTransparency','DayNightModus','CustomSubmenuBGColor','SubmenuBGTransparency','FirstSettings','ConfigButton',
	'SkinSettings','SaveDayNight','CustomHomeButtonAction1','CustomHomeButtonAction2','CustomHomeButtonAction3',
	'CustomHomeButtonAction4','CustomHomeButtonAction5','CustomHomeButtonAction6','CustomMusicPath1','CustomMusicPath2',
	'CustomMusicPath3','CustomMusicPath4','CustomMusicPath5','CustomMusicPath6','CustomVideoPath1','CustomVideoPath2',
	'CustomVideoPath3','CustomVideoPath4','CustomVideoPath5','CustomVideoPath6','CustomSettingsIcon1','CustomSettingsIcon2',
	'CustomSettingsIcon3','CustomSettingsIcon4','CustomSettingsIcon5','CustomSettingsIcon6','CustomShutdownIcon1','CustomShutdownIcon2',
	'CustomShutdownIcon3','CustomShutdownIcon4','CustomShutdownIcon5','CustomShutdownIcon6','Startup_Playlist_Path',
	'CustomVisBgFullPath','HideHomeButtonTime','HideHomeButtonMusicPlayerTitle','HideHomeButtonPictures','UseVisBg',
	'HideHomeButtonVideo','PlayerControlsShowAudioInfo','HideHomeButtonFavourites','HideRandomRepeat','HideHomeButtonRadioStationName',
	'HideHomeButtonNavigation','HideHomeButtonRadio','HideWeatherTitleWidget','PlayerControlsShowVideoInfo','HideHomeButtonConnect3g',
	'HideHomeButtonShutdownDialog','HideHomeButtonPrograms','HideHomeButtonMusic','HideHomeButtonFileManager','HideSettingsManager',
	'UseVisBgCover','HideHomeButtonWeather','ShowOutlines','EnableBottomBG','EnablePlayerButtonsBG','PlayerControlsSubMenuVisible',
	'Hide1024x600Fix','EnableBGPictures','UseCustomBackground','MediaSubMenuVisible','EnableBGColor','UseCustomLogo',
	'HideVisualisationHome','Enable_Clock_Animation','Enable_Clock_Second_Hand','Show_Clock_white','AddCustomButton1',
	'AddCustomButton2','AddCustomButton3','UseCustomMusic','UseCustomVideo','UseVisBgFull','MuteVolume','RadioAddonBackground',
	'RadioAddonRadioText','ListRadioStation','DeleteRadioStation','SaveRadioStation','SkinHelper.EnableAnimatedPosters',
	'SkinHelper.EnablePVRThumbs','HomePosNavi','HomePosShutdown','CustomHomeButton2Pos','HomePosOBD','CustomHomeButtonPos',
	'HomePosVideo','CustomHomeButtonLabel','SubtitleScript_Path','HomePos3G','HomePosRadio','HomePosSettings',
	'HomePosShutdownNoDialogNoDialog','HomePosMusic','CustomHomeButton3Icon','CustomHomeButton2Label','CustomHomeButton3Pos',
	'CustomHomeButton2Icon','CustomHomeButtonIcon','HomePosShutdownNoDialog','HomePosWeather','CustomHomeButton3Label',
	'CustomHomeButtonAction','CustomHomeButton2Action','CustomHomeButton3Action','CustomMusicPath','CustomVideoPath',
	'EnableTitleText','EnableTempOutput']

def readDaySetting(command):
    xbmc.executebuiltin('Skin.SetString(' + command + ',' + addon.getSetting("day_" + command) + ')')

def readNightSetting(command):
    xbmc.executebuiltin('Skin.SetString(' + command + ',' + addon.getSetting("night_" + command) + ')')

def saveDaySetting(command):
    addon.setSetting('day_' + command,str(xbmc.getInfoLabel('Skin.String(' + command + ')')))

def saveNightSetting(command):
    addon.setSetting('night_' + command,str(xbmc.getInfoLabel('Skin.String(' + command + ')')))

def loadDay():
	global COMMANDLIST
	xbmcgui.Window(10000).setProperty('xtouch.updating','true')
	time.sleep(0.5)
	for item in COMMANDLIST:
	    readDaySetting(item)
	time.sleep(1)
	xbmcgui.Window(10000).setProperty('xtouch.updating','false')
	addon.setSetting('state','day')
	xbmcgui.Window(10000).setProperty('xtouch.daynight','day')

def loadNight():
	global COMMANDLIST
	xbmcgui.Window(10000).setProperty('xtouch.updating','true')
	time.sleep(0.5)
	for item in COMMANDLIST:
	    readNightSetting(item)
	time.sleep(1)
	xbmcgui.Window(10000).setProperty('xtouch.updating','false')
	addon.setSetting('state','night')
	xbmcgui.Window(10000).setProperty('xtouch.daynight','night')

def saveDay():
	global COMMANDLIST
	xbmcgui.Window(10000).setProperty('xtouch.saving','true')
	time.sleep(0.5)
	for item in COMMANDLIST:
	    saveDaySetting(item)
	time.sleep(1)
	xbmcgui.Window(10000).setProperty('xtouch.saving','false')

def saveNight():
	global COMMANDLIST
	xbmcgui.Window(10000).setProperty('xtouch.saving','true')
	time.sleep(0.5)
	for item in COMMANDLIST:
	    saveNightSetting(item)
	time.sleep(0.5)
	xbmcgui.Window(10000).setProperty('xtouch.saving','false')

count = len(sys.argv) - 1
if count > 0:
    given_arg = sys.argv[1]
    if given_arg != "-1":
	if given_arg == "loadday":
	    loadDay()
    	    quit()

	if given_arg == "saveday":
	    saveDay()
    	    quit()

	if given_arg == "loadnight":
	    loadNight()
    	    quit()

	if given_arg == "savenight":
	    saveNight()
    	    quit()

class xtouch(xbmcgui.WindowXMLDialog):

    def onInit(self):
        xtouch.button_home=self.getControl(HOME_BUTTON)
        xtouch.button_back=self.getControl(BACK_BUTTON)
        xtouch.buttonfocus=self.getControl(BUTTON_FOCUS)
        xtouch.button_settings=self.getControl(SETTINGS_BUTTON)
	xbmcgui.Window(10000).setProperty('xtouch.updating','false')
	xbmcgui.Window(10000).setProperty('xtouch.saving','false')

	if str(xbmc.getSkinDir()) != "skin.carpc-xtouch":
	    xbmcgui.Window(10000).setProperty('xtouch.warning','true')
	else:
	    xbmcgui.Window(10000).setProperty('xtouch.warning','false')

    def onClick(self, controlID):

        if controlID == HOME_BUTTON:
            self.close()

        if controlID == BACK_BUTTON:
            self.close()

        if controlID == SETTINGS_BUTTON:
	    self.setFocus(self.buttonfocus)
	    addon.openSettings()
	    self.setFocus(self.buttonfocus)

        if controlID == LOADDAY_BUTTON:
	    loadDay()

        if controlID == LOADNIGHT_BUTTON:
	    loadNight()

        if controlID == SAVEDAY_BUTTON:
	    saveDay()

        if controlID == SAVENIGHT_BUTTON:
	    saveNight()

    def onFocus(self, controlID):
        pass
    
    def onControl(self, controlID):
        pass

xtouchdialog = xtouch("xtouch.xml", addonpath, 'default', '720')

xtouchdialog.doModal()
del xtouchdialog

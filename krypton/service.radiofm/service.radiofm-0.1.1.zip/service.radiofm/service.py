import xbmc
import xbmcgui
import xbmcaddon
import os
import sys
import socket
import time
import subprocess
from threading import Thread

# Get global paths
addon = xbmcaddon.Addon(id='service.radiofm')
addonpath = addon.getAddonInfo('path').decode("utf-8")

if str(xbmc.getCondVisibility('System.HasAddon(resource.images.radiofm)')) == "1":
    addonlogopath = xbmcaddon.Addon(id='resource.images.radiofm').getAddonInfo('path').decode("utf-8") + "/resources/"
else:
    addonlogopath = "/tmp/"

monitor = xbmc.Monitor()
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
KILL = 0

failsave = str(xbmc.getCondVisibility('System.HasAddon(service.radioFM.watchdog)'))
if failsave == "1":
    xbmcgui.Dialog().ok("$ADDON[plugin.program.radioFM 30029]","$ADDON[plugin.program.radioFM 30030]","$ADDON[plugin.program.radioFM 30031]")
    quit()

def CarpcController_SendCommand(command):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 5005

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(command + "\0", (UDP_IP, UDP_PORT))

def Radio_SendCommand(command):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 5005
        sock.sendto("radio_" + command + "\0", (UDP_IP, UDP_PORT))

def updateWindow():
    global KILL
    while True and KILL != 1:
	radiofreqlogo = xbmcgui.Window(10000).getProperty('Radio.Frequency')
        if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "true":
	    loopcount = 1
	    check = 0
	    while True:
		if loopcount <= 8 and str(radiofreqlogo) == str(xbmcgui.Window(10000).getProperty('Radio.StationFreq' + str(loopcount))):
		    xbmcgui.Window(10000).setProperty('Radio.CurrentStation',str(loopcount))
		    check = 1

		if loopcount >= 9 and str(radiofreqlogo) == str(xbmcgui.Window(10000).getProperty('Radio.StationFreq' + str(loopcount - 8) + 'b')):
	    	    xbmcgui.Window(10000).setProperty('Radio.CurrentStation',str(loopcount))
		    check = 1

		loopcount = loopcount + 1
		if loopcount > 16:
	    	    break
	    if check != 1:
    		xbmcgui.Window(10000).setProperty('Radio.CurrentStation','0')

	if str(addon.getSetting('ShowStationLogos')) == "true":
	    if str(addon.getSetting('UseCustomLogos')) == "true":
		radionamelogo = xbmcgui.Window(10000).getProperty('Radio.StationName').replace(" ","").replace("\"","").replace("*","+").lower()
    		defaultlogopath = addon.getSetting('StationLogosPath')
    		radiologo = defaultlogopath + radiofreqlogo + ".png"
    		radiologoname = defaultlogopath + radionamelogo + ".png"
	    else:
		country = addon.getSetting('country')
		radionamelogo = xbmcgui.Window(10000).getProperty('Radio.StationName').replace(" ","").replace("\"","").replace("*","+").lower()
    		radiologo = addonlogopath + country + "/" + radiofreqlogo + ".png"
    		radiologoname = addonlogopath + country + "/" + radionamelogo + ".png"

	    if str(addon.getSetting('UseStationName')) == "false":
		if os.path.isfile(radiologo) == True:
		    if xbmcgui.Window(10000).getProperty('Radio.StationLogo') != radiologo:
        		xbmcgui.Window(10000).setProperty('Radio.Logo','false')
			time.sleep(0.3)
        		xbmcgui.Window(10000).setProperty('Radio.StationLogo',radiologo)
        		xbmcgui.Window(10000).setProperty('Radio.Logo','true')
		else:
		    if xbmcgui.Window(10000).getProperty('Radio.StationLogo') != '':
        		xbmcgui.Window(10000).setProperty('Radio.Logo','false')
			time.sleep(0.3)
        		xbmcgui.Window(10000).setProperty('Radio.StationLogo','')
    	    		xbmcgui.Window(10000).setProperty('Radio.Logo','true')
	    else:
		if os.path.isfile(radiologoname) == True:
		    if xbmcgui.Window(10000).getProperty('Radio.StationLogo') != radiologoname:
        		xbmcgui.Window(10000).setProperty('Radio.Logo','false')
			time.sleep(0.3)
        		xbmcgui.Window(10000).setProperty('Radio.StationLogo',radiologoname)
        		xbmcgui.Window(10000).setProperty('Radio.Logo','true')
			xbmcgui.Window(10000).setProperty('Radio.LogoIdentifiedFrequency',xbmcgui.Window(10000).getProperty('Radio.Frequency'))
		else:
		    if xbmcgui.Window(10000).getProperty('Radio.Frequency') != xbmcgui.Window(10000).getProperty('Radio.LogoIdentifiedFrequency'):
			if xbmcgui.Window(10000).getProperty('Radio.StationLogo') != '':
        	    	    xbmcgui.Window(10000).setProperty('Radio.Logo','false')
		    	    time.sleep(0.3)
        	    	    xbmcgui.Window(10000).setProperty('Radio.StationLogo','')
    	    	    	    xbmcgui.Window(10000).setProperty('Radio.Logo','true')
	else:
	    xbmcgui.Window(10000).setProperty('Radio.StationLogo','')

	if str(xbmc.getCondVisibility('Skin.HasSetting(UseCustomLogo)')) == "1" and xbmcgui.Window(10000).getProperty('Radio.StationLogo') == '':
    	    xbmcgui.Window(10000).setProperty('Radio.LogoCustom','true')
	else:
    	    xbmcgui.Window(10000).setProperty('Radio.LogoCustom','false')
        time.sleep(1.0)

def updateLogo():
	if str(addon.getSetting('ShowStationLogos')) == "true":
	    if str(addon.getSetting('UseCustomLogos')) == "true":
		radiofreqlogo = xbmcgui.Window(10000).getProperty('Radio.Frequency')
		radionamelogo = xbmcgui.Window(10000).getProperty('Radio.StationName').replace(" ","").replace("\"","").replace("*","+").lower()
    		defaultlogopath = addon.getSetting('StationLogosPath')
    		radiologo = defaultlogopath + radiofreqlogo + ".png"
    		radiologoname = defaultlogopath + radionamelogo + ".png"
	    else:
		country = addon.getSetting('country')
		radiofreqlogo = xbmcgui.Window(10000).getProperty('Radio.Frequency')
		radionamelogo = xbmcgui.Window(10000).getProperty('Radio.StationName').replace(" ","").replace("\"","").replace("*","+").lower()
    		radiologo = addonlogopath + country + "/" + radiofreqlogo + ".png"
    		radiologoname = addonlogopath + country + "/" + radionamelogo + ".png"

    	    if str(xbmc.getCondVisibility('Skin.HasSetting(UseCustomLogo)')) == "1":
		nostationlogo = xbmc.getInfoLabel('Skin.String(CustomLogoPath)')
	    else:
		nostationlogo = ''

	    if str(addon.getSetting('UseStationName')) == "false":
		if os.path.isfile(radiologo) == True:
		    if xbmcgui.Window(10000).getProperty('Radio.StationLogo') != radiologo:
        		xbmcgui.Window(10000).setProperty('Radio.Logo','false')
			time.sleep(0.3)
        		xbmcgui.Window(10000).setProperty('Radio.StationLogo',radiologo)
        		xbmcgui.Window(10000).setProperty('Radio.Logo','true')
		else:
		    if xbmcgui.Window(10000).getProperty('Radio.StationLogo') != '':
        		xbmcgui.Window(10000).setProperty('Radio.Logo','false')
			time.sleep(0.3)
        		xbmcgui.Window(10000).setProperty('Radio.StationLogo','')
    	    		xbmcgui.Window(10000).setProperty('Radio.Logo','true')
	    else:
		if os.path.isfile(radiologoname) == True:
		    if xbmcgui.Window(10000).getProperty('Radio.StationLogo') != radiologoname:
        		xbmcgui.Window(10000).setProperty('Radio.Logo','false')
			time.sleep(0.3)
        		xbmcgui.Window(10000).setProperty('Radio.StationLogo',radiologoname)
        		xbmcgui.Window(10000).setProperty('Radio.Logo','true')
			xbmcgui.Window(10000).setProperty('Radio.LogoIdentifiedFrequency',xbmcgui.Window(10000).getProperty('Radio.Frequency'))
		else:
		    if xbmcgui.Window(10000).getProperty('Radio.Frequency') != xbmcgui.Window(10000).getProperty('Radio.LogoIdentifiedFrequency'):
			if xbmcgui.Window(10000).getProperty('Radio.StationLogo') != '':
        	    	    xbmcgui.Window(10000).setProperty('Radio.Logo','false')
		    	    time.sleep(0.3)
        	    	    xbmcgui.Window(10000).setProperty('Radio.StationLogo','')
    	    	    	    xbmcgui.Window(10000).setProperty('Radio.Logo','true')
	else:
	    xbmcgui.Window(10000).setProperty('Radio.StationLogo','')

def Init_Values():
	    if xbmc.getCondVisibility('Skin.String(ListRadioStation)') != 0:
		xbmc.executebuiltin('Skin.ToggleSetting(ListRadioStation)')
	    stationloop = 1
	    while True:
		checkfreq = addon.getSetting('Station' + str(stationloop) + '_Freq')
		checkname = addon.getSetting('Station' + str(stationloop))
		if checkfreq != "" and checkname != "- - -":
		    NewStationString = checkfreq + " - " + checkname
        	    xbmcgui.Window(10000).setProperty('Radio.Station' + str(stationloop),NewStationString)
        	    xbmcgui.Window(10000).setProperty('Radio.StationFreq' + str(stationloop),checkfreq)
	        stationloop = stationloop + 1
	        if stationloop > 8:
		    break

	    stationloop = 1
	    while True:
		checkfreq = addon.getSetting('Station' + str(stationloop) + 'b_Freq')
		checkname = addon.getSetting('Station' + str(stationloop) + 'b')
		if checkfreq != "" and checkname != "- - -":
		    NewStationString = checkfreq + " - " + checkname
        	    xbmcgui.Window(10000).setProperty('Radio.Station' + str(stationloop) + 'b',NewStationString)
        	    xbmcgui.Window(10000).setProperty('Radio.StationFreq' + str(stationloop) + 'b',checkfreq)
	        stationloop = stationloop + 1
	        if stationloop > 8:
		    break

	    stationloop = 1
	    while True:
        	station = str(xbmcgui.Window(10000).getProperty('Radio.Station' + str(stationloop)))
		if station == "":
        	    xbmcgui.Window(10000).setProperty('Radio.Station' + str(stationloop),'- - -')
	        stationloop = stationloop + 1
	        if stationloop > 8:
		    break

	    stationloop = 1
	    while True:
        	station = str(xbmcgui.Window(10000).getProperty('Radio.Station' + str(stationloop) + 'b'))
		if station == "":
        	    xbmcgui.Window(10000).setProperty('Radio.Station' + str(stationloop) + 'b','- - -')
	        stationloop = stationloop + 1
	        if stationloop > 8:
		    break

	    bgimage = addon.getSetting('custombackgroundimage')
	    setbgimage = str(addon.getSetting('custombackground'))
	    if setbgimage == "true":
		xbmc.executebuiltin('Skin.SetString(RadioAddonBackgroundImage,' + bgimage + ')')
	    else:
		xbmc.executebuiltin('Skin.SetString(RadioAddonBackgroundImage,radiodefault.jpg)')

	    xbmcgui.Window(10000).setProperty('Radio.ShowRadiotext',str(addon.getSetting('ShowRadiotext')))

def Tune_Station(command):
        storemode = str(xbmc.getCondVisibility('Skin.HasSetting(SaveRadioStation)'))
        delmode = str(xbmc.getCondVisibility('Skin.HasSetting(DeleteRadioStation)'))
        radiolist = str(xbmc.getCondVisibility('Skin.HasSetting(ListRadioStation)'))
        if radiolist == "1" :
	    command = command + 'b'

        if storemode == "1" and delmode == "1": # check if store or delmode active
	    station = str(xbmcgui.Window(10000).getProperty('Radio.' + str(command)))
            requestedFrequency = station.split(' ')
            if str(requestedFrequency[0]) != "-":
		Radio_SendCommand("tune_" + requestedFrequency[0])
    		xbmcgui.Window(10000).setProperty('Radio.Frequency',requestedFrequency[0])
    		xbmcgui.Window(10000).setProperty('Radio.RDS','- - -')
                if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
	                xbmc.Player().stop()
    	                CarpcController_SendCommand("system_mode_toggle")

def Cleanup_Station(command):
        storemode = str(xbmc.getCondVisibility('Skin.HasSetting(SaveRadioStation)'))
        delmode = str(xbmc.getCondVisibility('Skin.HasSetting(DeleteRadioStation)'))
        radiolist = str(xbmc.getCondVisibility('Skin.HasSetting(ListRadioStation)'))
        if radiolist == "1" :
	    command = command + 'b'
	commandfreq = command + '_Freq'

        if storemode == "1" and delmode == "1": # check if store or delmode active
	    station = str(xbmcgui.Window(10000).getProperty('Radio.' + str(command)))
            stationString = station.split('-')
	    stationName = str.strip(stationString[1])
	    stationFrequency = str.strip(stationString[0])

	    if stationName == "":
	    	stationName = "Unknown"
	    if stationFrequency == "":
	    	stationName = "- - -"
    		xbmcgui.Window(10000).setProperty('Radio.' + command,'- - -')
	    else:
		NewStationString = stationFrequency + " - " + stationName
    		xbmcgui.Window(10000).setProperty('Radio.' + command,NewStationString)

	    addon.setSetting(command,stationName)
	    addon.setSetting(commandfreq,stationFrequency)

# Read sys args to open mapping dialog
count = len(sys.argv) - 1
if count > 0:
    controlID = sys.argv[1]

    if controlID == "TUNE_DOWN":
        if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
            xbmc.Player().stop()
    	    CarpcController_SendCommand('SYSTEM:SMODE_1')
	    xbmcgui.Window(10000).setProperty('Radio.Active','true')
        Radio_SendCommand("tune_down")
	xbmcgui.Window(10000).setProperty('Radio.Logo','false')

    if controlID == "TUNE_UP":
        if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
            xbmc.Player().stop()
    	    CarpcController_SendCommand('SYSTEM:SMODE_1')
	    xbmcgui.Window(10000).setProperty('Radio.Active','true')
        Radio_SendCommand("tune_up")
	xbmcgui.Window(10000).setProperty('Radio.Logo','false')

    if controlID == "SEEK_DOWN":
        if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
            xbmc.Player().stop()
    	    CarpcController_SendCommand('SYSTEM:SMODE_1')
	    xbmcgui.Window(10000).setProperty('Radio.Active','true')
        Radio_SendCommand("seek_down")
	xbmcgui.Window(10000).setProperty('Radio.Logo','false')

    if controlID == "SEEK_UP":
        if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
            xbmc.Player().stop()
    	    CarpcController_SendCommand('SYSTEM:SMODE_1')
	    xbmcgui.Window(10000).setProperty('Radio.Active','true')
        Radio_SendCommand("seek_up")
	xbmcgui.Window(10000).setProperty('Radio.Logo','false')

    if controlID == "STATION1":
        Tune_Station("Station1")
        Cleanup_Station("Station1")
        CarpcController_SendCommand('SYSTEM:SMODE_1')
        xbmcgui.Window(10000).setProperty('Radio.Active','true')
	xbmcgui.Window(10000).setProperty('Radio.Logo','false')

    if controlID == "STATION2":
        Tune_Station("Station2")
        Cleanup_Station("Station2")
        CarpcController_SendCommand('SYSTEM:SMODE_1')
        xbmcgui.Window(10000).setProperty('Radio.Active','true')
	xbmcgui.Window(10000).setProperty('Radio.Logo','false')

    if controlID == "STATION3":
        Tune_Station("Station3")
        Cleanup_Station("Station3")
        CarpcController_SendCommand('SYSTEM:SMODE_1')
        xbmcgui.Window(10000).setProperty('Radio.Active','true')
	xbmcgui.Window(10000).setProperty('Radio.Logo','false')

    if controlID == "STATION4":
        Tune_Station("Station4")
        Cleanup_Station("Station4")
        CarpcController_SendCommand('SYSTEM:SMODE_1')
        xbmcgui.Window(10000).setProperty('Radio.Active','true')
	xbmcgui.Window(10000).setProperty('Radio.Logo','false')

    if controlID == "STATION5":
        Tune_Station("Station5")
        Cleanup_Station("Station5")
        CarpcController_SendCommand('SYSTEM:SMODE_1')
        xbmcgui.Window(10000).setProperty('Radio.Active','true')
	xbmcgui.Window(10000).setProperty('Radio.Logo','false')

    if controlID == "STATION6":
        Tune_Station("Station6")
        Cleanup_Station("Station6")
        CarpcController_SendCommand('SYSTEM:SMODE_1')
        xbmcgui.Window(10000).setProperty('Radio.Active','true')
	xbmcgui.Window(10000).setProperty('Radio.Logo','false')

    if controlID == "STATION7":
        Tune_Station("Station7")
        Cleanup_Station("Station7")
        CarpcController_SendCommand('SYSTEM:SMODE_1')
        xbmcgui.Window(10000).setProperty('Radio.Active','true')
	xbmcgui.Window(10000).setProperty('Radio.Logo','false')

    if controlID == "STATION8":
        Tune_Station("Station8")
        Cleanup_Station("Station8")
	CarpcController_SendCommand('SYSTEM:SMODE_1')
	xbmcgui.Window(10000).setProperty('Radio.Active','true')
	xbmcgui.Window(10000).setProperty('Radio.Logo','false')

    if controlID == "INIT":
        Init_Values()

    quit()

Init_Values()

t1 = Thread( target=updateWindow)
t1.setDaemon( True )
t1.start()

# Wait
while not monitor.abortRequested():
	if monitor.waitForAbort():
	    KILL = 1
	    time.sleep(0.3)
	    break
	    quit()
